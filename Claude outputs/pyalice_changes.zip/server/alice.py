#!/usr/bin/env python3
"""Alice — run with: python alice.py"""
import subprocess, sys, os, time, threading, webbrowser
import requests as req

# Startup timing — measure how long each phase takes so we can tune caching.
_START_TIME = time.monotonic()
def _elapsed(label: str = "") -> str:
    return f"[{int(time.monotonic() - _START_TIME)}s] {label}"

# On Windows the console defaults to cp1252, which crashes on any non-Latin-1
# character (e.g. ≤, em-dash, philosophers' symbols) that the LLM may emit.
if os.name == "nt":
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, OSError):
            pass

from logging_setup import init_logging

# ── Windows CUDA DLL path fix ─────────────────────────────────────────────────
if os.name == "nt":
    _cuda_env = os.environ.get("CUDA_PATH")
    _candidates = [_cuda_env] if _cuda_env else []
    _root = r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA"
    if os.path.exists(_root):
        _candidates += [os.path.join(_root, v) for v in sorted(os.listdir(_root), reverse=True)]
    for _p in _candidates:
        for _sub in ("bin", os.path.join("bin", "x64")):
            _d = os.path.join(_p, _sub)
            if os.path.exists(_d) and hasattr(os, "add_dll_directory"):
                try:
                    os.add_dll_directory(_d)
                except OSError:
                    pass

# ── Auto-install if needed ────────────────────────────────────────────────────
_SERVER_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT_DIR = os.path.dirname(_SERVER_DIR)

import args
ARGS = args.parse()


def _tts_assets_present() -> bool:
    tts_dir = os.path.join(_SERVER_DIR, "models", "tts")
    return all(
        os.path.exists(os.path.join(tts_dir, name))
        for name in ("kokoro-v0_19.onnx", "voices.bin")
    )


def _llama_server_present() -> bool:
    base = os.path.join(_SERVER_DIR, "llama-cpp")
    return any(
        os.path.isfile(os.path.join(base, exe))
        for exe in ("llama-server.exe", "llama-server")
    )


def _forge_present() -> bool:
    return os.path.isdir(os.path.join(_SERVER_DIR, "stable-diffusion-webui-forge"))


def _needs_install() -> bool:
    if args.has("pytest"):
        return False
    if not (_tts_assets_present() and _llama_server_present() and _forge_present()):
        return True
    import importlib.util
    required = ["fastapi", "uvicorn", "pydantic", "requests",
                "kokoro_onnx", "faster_whisper", "av"]
    return not all(importlib.util.find_spec(pkg) is not None for pkg in required)

if _needs_install():
    _install = os.path.join(_ROOT_DIR, "install.py")
    print("\nDependencies missing — running install.py first...\n")
    result = subprocess.run([sys.executable, _install])
    if result.returncode != 0:
        print("\ninstall.py failed. Fix the errors above and try again.")
        sys.exit(1)
    print("\nInstall complete — starting Alice...\n")

_PYTHON_LOG_FILE = init_logging("python-server")

# ── Imports (after install check) ────────────────────────────────────────────
import json, logging
import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

import config
import llm
import state
import tts
import image

HOST = "127.0.0.1"
PORT = int(config.CFG.get("port", getattr(config, "PORT", 8000)))

# ── Runtime flags ─────────────────────────────────────────────────────────────
NO_SPEECH  = ARGS.no_speech
NO_FORGE   = ARGS.no_forge
TEST_MODE  = ARGS.test_mode
AUTO_IMAGE = ARGS.auto_image
INTERACTIVE = sys.stdin.isatty() and sys.stdout.isatty()

if ARGS.voices:
    from tts import VOICES
    print("\nAvailable TTS voices:\n")
    for v in VOICES:
        print(f"  {v}")
    print()
    sys.exit(0)

_TEST_MSG     = "tell me something interesting about yourself"
_PERSONA_ARG  = ARGS.persona


def _resolve_persona(arg: str) -> str:
    if not arg:
        return arg
    low   = arg.lower()
    names = list(config.PERSONAS.keys())
    for n in names:
        if n.lower() == low:           return n
    for n in names:
        if n.lower().startswith(low):  return n
    for n in names:
        if low in n.lower():           return n
    return arg


_TEST_PERSONA = _resolve_persona(_PERSONA_ARG or "Alice")

# ── Logging ───────────────────────────────────────────────────────────────────
class _NoSpamFilter(logging.Filter):
    def filter(self, record):
        msg = record.getMessage()
        return "/progress" not in msg and "/favicon" not in msg

_LOG_CONFIG = {
    "version": 1, "disable_existing_loggers": False,
    "formatters": {
        "default": {"()": "uvicorn.logging.DefaultFormatter",
                    "fmt": "\033[33m[%(asctime)s]\033[0m %(levelprefix)s %(message)s",
                    "datefmt": "%H:%M:%S", "use_colors": None},
        "access":  {"()": "uvicorn.logging.AccessFormatter",
                    "fmt": '\033[33m[%(asctime)s]\033[0m %(levelprefix)s %(client_addr)s - "%(request_line)s" %(status_code)s',
                    "datefmt": "%H:%M:%S"},
        "plain":   {"format": "%(asctime)s %(levelname)s [%(name)s] %(message)s"},
    },
    "handlers": {
        "default": {"formatter": "default", "class": "logging.StreamHandler", "stream": "ext://sys.stderr"},
        "access":  {"formatter": "access",  "class": "logging.StreamHandler", "stream": "ext://sys.stdout",
                    "filters": ["no_spam"]},
        "file":    {"formatter": "plain", "class": "logging.FileHandler", "filename": _PYTHON_LOG_FILE, "encoding": "utf-8"},
    },
    "filters": {"no_spam": {"()": _NoSpamFilter}},
    "loggers": {
        "uvicorn":        {"handlers": ["default", "file"], "level": "INFO", "propagate": False},
        "uvicorn.error":  {"handlers": ["default", "file"], "level": "INFO", "propagate": False},
        "uvicorn.access": {"handlers": ["access", "file"],  "level": "INFO", "propagate": False},
    },
}

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI()
app.mount("/static", StaticFiles(directory=config.STATIC_DIR), name="static")

from routes.chat      import router as chat_router
from routes.image_api import router as image_router
from routes.persona   import router as persona_router
from routes.audio     import router as audio_router
from routes.system    import router as system_router
from routes.group     import router as group_router

app.include_router(chat_router)
app.include_router(image_router)
app.include_router(persona_router)
app.include_router(audio_router)
app.include_router(system_router)
app.include_router(group_router)

# ── Startup ───────────────────────────────────────────────────────────────────
def _ensure_llm_ready(timeout: int = 120):
    llm.load_llm()
    if not llm.wait_until_ready(timeout):
        raise RuntimeError("llama.cpp server did not become ready; check llama-server output.")
    import vram
    vram.notify_llm_ready()
    vram.log_resources("LLM ready")
    print(_elapsed("LLM ready"))


def _ensure_tts_ready():
    import threading
    def _load():
        if tts.load_tts():
            print(f"[{config.NAME}] TTS ready.")
        else:
            print(f"[{config.NAME}] TTS failed to load — audio disabled.")
    threading.Thread(target=_load, daemon=True, name="tts-loader").start()
    print(f"[{config.NAME}] TTS loading in background...")


def _ensure_forge_ready():
    import vram
    vram.setup(config.CFG["forge_url"])
    if not image.start_forge():
        raise RuntimeError("Failed to launch Stable Diffusion Forge.")
    print(_elapsed("Forge started"))
    sd_checkpoint = config.CFG.get("sd_checkpoint", "")

    # Skip set_forge_model (slow refresh-checkpoints included) if Forge already has
    # the right checkpoint. Fall back to full set when it differs or check fails.
    _needs_model_set = True
    try:
        opts = req.get(f"{config.CFG['forge_url']}/sdapi/v1/options", timeout=5).json()
        current = opts.get("sd_model_checkpoint", "")
        if current and (sd_checkpoint in current or current in sd_checkpoint):
            _needs_model_set = False
            print(f"[forge] Checkpoint already correct: {current}")
            from image.forge import _push_forge_settings
            _push_forge_settings(config.CFG["forge_url"])
    except Exception:
        pass

    if _needs_model_set:
        if not image.set_forge_model(sd_checkpoint):
            raise RuntimeError(f"Forge could not select checkpoint '{sd_checkpoint}'.")

    # Always warmup: keep the checkpoint hot in VRAM so image gen doesn't pay
    # the 15-30s reload cost. vram_swap only kills the LLM during generation —
    # Forge itself never needs to be evicted on an 8GB card with a sub-5GB model.
    image.warmup_forge()


def _startup():
    import vram as _vram_mod
    _vram_mod.log_resources("startup baseline")

    _vram_swap = config.CFG.get("vram_swap_for_image", False)

    if not NO_FORGE and _vram_swap:
        # vram_swap: Forge must start before LLM so the checkpoint is evicted first,
        # freeing VRAM for the LLM. Only needed for models >5GB on 8GB GPUs.
        _ensure_forge_ready()

    _ensure_llm_ready()

    if not state._active_persona_key or state._active_persona_key not in config.PERSONAS:
        state._active_persona_key = next(iter(config.PERSONAS), config.NAME)

    llm.load_history()

    if AUTO_IMAGE:
        config.CFG.setdefault("image", {})["auto_every"] = 1
        print(f"[{config.NAME}] Auto-image enabled (--auto-image)")

    if not NO_SPEECH:
        _ensure_tts_ready()

    if not NO_FORGE and not _vram_swap:
        _ensure_forge_ready()
    elif NO_FORGE:
        print(f"[{config.NAME}] Skipping Forge startup (--no-forge)")


def _listener_pid(host: str, port: int):
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        if sock.connect_ex((host, port)) != 0:
            return None

    if os.name == "nt":
        result = subprocess.run(
            ["netstat", "-ano", "-p", "tcp"],
            capture_output=True,
            text=True,
            check=False,
        )
        for line in result.stdout.splitlines():
            parts = line.split()
            if len(parts) >= 5 and parts[0].upper() == "TCP" and parts[1].endswith(f":{port}") and parts[3].upper() == "LISTENING":
                try:
                    return int(parts[4])
                except ValueError:
                    return None
        return None

    result = subprocess.run(
        ["lsof", "-ti", f"tcp:{port}"],
        capture_output=True,
        text=True,
        check=False,
    )
    for line in result.stdout.splitlines():
        line = line.strip()
        if line.isdigit():
            return int(line)
    return None


def _kill_listener(host: str, port: int) -> bool:
    pid = _listener_pid(host, port)
    if not pid:
        return False

    print(f"[{config.NAME}] Port {port} is already in use by PID {pid}. Terminating it and retrying...")
    try:
        if os.name == "nt":
            result = subprocess.run(
                ["taskkill", "/PID", str(pid), "/F"],
                capture_output=True,
                text=True,
                check=False,
            )
        else:
            result = subprocess.run(
                ["kill", "-TERM", str(pid)],
                capture_output=True,
                text=True,
                check=False,
            )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "").strip()
            print(f"[{config.NAME}] Could not terminate PID {pid}: {detail or 'unknown error'}")
            return False
    except Exception as e:
        print(f"[{config.NAME}] Could not terminate PID {pid}: {e}")
        return False

    deadline = time.time() + 5
    while time.time() < deadline:
        if _listener_pid(host, port) is None:
            return True
        time.sleep(0.2)

    print(f"[{config.NAME}] Port {port} is still busy after terminating PID {pid}.")
    return False


_ALICE_BANNER_LETTERS = {
    "A": [" ██  ", "█  █ ", "█████", "█  █ ", "█  █ "],
    "L": ["█    ", "█    ", "█    ", "█    ", "█████"],
    "I": ["███", " █ ", " █ ", " █ ", "███"],
    "C": [" ████", "█    ", "█    ", "█    ", " ████"],
    "E": ["█████", "█    ", "████ ", "█    ", "█████"],
}
_ALICE_BANNER_COLORS = ["\033[96m", "\033[95m", "\033[94m", "\033[92m", "\033[93m"]


def _print_banner(name: str) -> None:
    """Print an ANSI block-letter banner for `name` when it's the default
    "Alice" persona; any other configured name falls back to the plain
    boxed banner (the block font only covers A/L/I/C/E)."""
    letters = name.upper()
    rows = None
    if all(ch in _ALICE_BANNER_LETTERS for ch in letters):
        rows = [_ALICE_BANNER_LETTERS[ch] for ch in letters]
    if not rows:
        print("=" * 60)
        print(f"  {name}")
        print("=" * 60)
        return
    reset = "\033[0m"
    for row_idx in range(5):
        line_parts = []
        for letter_idx, letter_rows in enumerate(rows):
            color = _ALICE_BANNER_COLORS[letter_idx % len(_ALICE_BANNER_COLORS)]
            line_parts.append(f"{color}{letter_rows[row_idx]}{reset}")
        print("  " + "  ".join(line_parts))


if __name__ == "__main__":
    print()
    _print_banner(config.NAME)
    print()
    print(f"[{config.NAME}] Starting server at {config.ALICE_URL}")

    from utils import IS_WSL
    if IS_WSL:
        try:
            import socket
            wsl_ip = socket.gethostbyname(socket.gethostname())
            print(f"        WSL2 detected. If localhost doesn't work, try http://{wsl_ip}:{PORT}")
        except Exception:
            pass

    _kill_listener(HOST, PORT)

    def _run_startup():
        try:
            _startup()
        except RuntimeError as exc:
            print(f"\n[{config.NAME}] Preflight failed: {exc}")

        # Launch the standalone SD console (sd_app/) only after our own Forge
        # startup has settled — sd_app's start_forge() sees Forge already
        # running and skips launching its own, avoiding a duplicate Forge
        # console spawning from both processes racing to start it. Best-effort:
        # non-fatal if sd_app is already running or its port is taken.
        try:
            subprocess.Popen([sys.executable, os.path.join(_ROOT_DIR, "sd_app", "app.py")],
                              cwd=os.path.join(_ROOT_DIR, "sd_app"))
        except Exception as e:
            print(f"[{config.NAME}] Could not launch sd_app: {e}")

    threading.Thread(target=_run_startup, daemon=True, name="startup").start()

    if _PERSONA_ARG and not TEST_MODE:
        def _apply_persona():
            time.sleep(3)
            try:
                resolved = _resolve_persona(_PERSONA_ARG)
                req.post(f"http://{HOST}:{PORT}/persona/{resolved}", timeout=5)
                print(f"[startup] persona set to: {resolved}")
            except Exception as e:
                print(f"[startup] could not set persona: {e}")
        threading.Thread(target=_apply_persona, daemon=True).start()

    if TEST_MODE:
        def _run_test():
            base = f"http://{HOST}:{PORT}"
            for _ in range(60):
                time.sleep(1)
                try:
                    if req.get(f"{base}/info", timeout=1).json().get("llm_ready"):
                        break
                except Exception:
                    pass
            try:
                r = req.post(f"{base}/persona/{_TEST_PERSONA}", timeout=5)
                print(f"\n[test] persona: {_TEST_PERSONA} → {r.json()}")
            except Exception as e:
                print(f"\n[test] could not set persona: {e}")
            print(f"\n[test] sending: {_TEST_MSG!r}")
            reply = ""
            try:
                with req.post(f"{base}/chat", json={"message": _TEST_MSG}, stream=True, timeout=120) as r:
                    for line in r.iter_lines():
                        if not line: continue
                        line = line.decode() if isinstance(line, bytes) else line
                        if not line.startswith("data: "): continue
                        d = json.loads(line[6:])
                        if d.get("delta"): print(d["delta"], end="", flush=True)
                        if d.get("done"):  reply = d.get("reply", "")
            except Exception as e:
                print(f"\n[test] chat error: {e}"); return
            print(f"\n[test] reply done ({len(reply)} chars). Triggering /image ...")
            try:
                r = req.post(f"{base}/image", json={"extra": ""}, timeout=300)
                url = r.json().get("url")
                print(f"[test] /image done. URL: {url}")
                if url and INTERACTIVE:
                    webbrowser.open(f"http://{HOST}:{PORT}{url}")
            except Exception as e:
                print(f"[test] image error: {e}")
        threading.Thread(target=_run_test, daemon=True).start()

    if INTERACTIVE:
        def _open():
            time.sleep(2)
            from utils import IS_WSL
            if IS_WSL:
                import shutil, subprocess
                opener = shutil.which("wslview") or "explorer.exe"
                subprocess.Popen([opener, config.ALICE_URL],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                webbrowser.open(config.ALICE_URL)
        threading.Thread(target=_open, daemon=True).start()
    else:
        print("        NOTE: Non-interactive session detected; not opening browser.")

    try:
        uvicorn.run(app, host=HOST, port=PORT, log_config=_LOG_CONFIG)
    except BaseException as e:
        print(f"\n[{config.NAME}] Server failed: {type(e).__name__}: {e}")
