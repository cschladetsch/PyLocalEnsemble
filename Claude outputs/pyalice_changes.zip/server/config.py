import os, re, json, shutil

ALICE_DIR     = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SERVER_DIR    = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR    = os.path.join(SERVER_DIR, "static")
FORGE_DIR     = os.path.join(SERVER_DIR, "stable-diffusion-webui-forge")
FORGE_BAT     = os.path.join(FORGE_DIR, "webui.ps1" if os.name == "nt" else "webui.sh")
MODEL_DIR     = os.path.join(SERVER_DIR, "models")
TTS_DIR       = os.path.join(SERVER_DIR, "models", "tts")
HISTORY_FILE  = os.path.join(ALICE_DIR, "history.json")

def history_file_for(persona_key: str) -> str:
    safe = persona_key.lower().replace(" ", "_").replace("/", "_").replace("\\", "_")
    return os.path.join(ALICE_DIR, f"history_{safe}.json")
CONFIG_FILE   = os.path.join(ALICE_DIR, "alice.json")
PERSONAS_FILE = os.path.join(ALICE_DIR, "personas.json")
PACKS_DIR     = os.path.join(ALICE_DIR, "personas", "packs")
MINE_DIR      = os.path.join(ALICE_DIR, "personas", "mine")

_DEFAULT_CONFIG = {
    "name":               "Alice",
    "port":               8000,
    "forge_url":          "http://localhost:7860",
    "llama_url":          "http://127.0.0.1:8080",
    "model_path":         "",
    "model_dir":          "",
    "llama_model":        "mistral-nemo",
    "stt_silence_seconds": 3,
    "appearance":   "woman, long blonde hair, blue eyes, elegant, poised, expressive eyes, soft lighting",
    "negative_prompt": "(worst quality:2), (low quality:2), lowres, (bad anatomy:1.5), (bad hands:1.8), (mutated hands:1.7), (extra fingers:1.8), (missing fingers:1.7), (fused fingers:1.8), (too many fingers:1.8), (malformed fingers:1.7), (deformed fingers:1.7), (poorly drawn fingers:1.6), poorly drawn hands, (six fingers:1.9), (seven fingers:1.9), (eight fingers:1.9), (four fingers:1.6), (three fingers:1.6), (wrong number of fingers:1.8), poorly drawn face, (deformed iris:1.4), (deformed pupils:1.4), mutation, deformed, blurry, bad proportions, (extra limbs:1.4), disfigured, gross proportions, malformed limbs, missing arms, missing legs, extra arms, extra legs, floating limbs, disconnected limbs, out of frame, cropped, duplicate, morbid, mutilated, cloned face, long neck, text, signature, watermark, username, jpeg artifacts, semi-realistic, cgi, 3d, render, sketch, cartoon, drawing, anime",
    "system_prompt": (
        "You are Alice. Respond always in first person as Alice — never narrate in third person.\n"
        "You are intelligent, witty, and fully present.\n"
        "You speak in measured, literary prose. You never break character.\n"
        "Never write disclaimers, notes, warnings, or meta-commentary of any kind.\n"
        "Never use phrases like 'please note', 'I should mention', 'as an AI', or 'I aimed to'.\n"
        "Never describe yourself or the scene in third person. Speak as yourself, directly.\n"
        "Keep replies concise — 2 to 4 sentences unless a longer response is genuinely needed."
    ),
    "llama_server": {
        "n_gpu_layers":  33,
        "ctx_size":      4096,
        "batch_size":    512,
        "threads":       8,
        "chat_template": "chatml",
    },
    "tts": {
        "voice":       "af_bella",
        "speed":       0.78,
        "pitch":       0.94,
        "chunk_chars": 600,
    },
    "image": {
        "steps":        25,
        "width":        512,
        "height":       768,
        "cfg_scale":    7,
        "sampler_name": "DPM++ SDE Karras",
        "suffix":       "RAW photo, 8k uhd, dslr, soft lighting, high quality, film grain, Fujifilm XT3, photorealistic, (high detailed skin:1.2), (perfect hands:1.3), (five fingers:1.2)",
        "auto_every":   0,
        "hires_fix":    True,
        "hires_scale":  1.5,
        "hires_steps":  15,
        "hires_denoising": 0.45,
        "hires_upscaler": "Latent",
        "auto_pin_seed":  True,
        "adetailer_face": True,
    },
    "demo": {
        "user_name":    "User",
        "user_voice":   "am_adam",
        "user_speed":   0.88,
        "user_pitch":   0.88,
        "context_messages": 12,
        "user_persona": "default",
        "user_personas": {
            "default":      "A curious, thoughtful person who enjoys good conversation.",
            "intellectual": "A sharp, curious thinker who probes ideas and draws unexpected connections.",
            "playful":      "An irreverent, witty person who keeps things light but knows when to be serious.",
            "romantic":     "A deeply feeling person who notices beauty in small things.",
            "reflective":   "A measured, introspective person who listens carefully before speaking.",
        },
    },
    "memory": {
        "max_history": 16,
        "keep_recent": 8,
        "max_chars":   1500,
    },
    "llm_params": {
        "max_tokens":        150,
        "temperature":       0.9,
        "top_p":             0.92,
        "repeat_penalty":    1.25,
        "presence_penalty":  0.8,
        "frequency_penalty": 0.5,
        # Some GGUFs emit these as literal generated text instead of hitting
        # their real EOS token (e.g. leftover delimiters from fine-tuning
        # data), which otherwise leaks straight through to the chat UI.
        "stop": ["<|endoftext|>", "<|im_end|>", "<|im_start|>"],
    },
    "quick_image":       True,
    "vram_swap_for_image": True,
    "banned_phrases": [
        "moonlight", "moonlit", "starry skies", "under the stars", "under these stars",
        "beneath the stars", "star-filled", "ancient and primal",
        "whispers of", "shadows dance", "the air crackles",
        "primal hunger", "smoldering gaze",
    ],
}


def resolve_path(p: str) -> str:
    if not p: return ""
    p = os.path.expanduser(p)
    if os.path.isabs(p):
        return p
    return os.path.normpath(os.path.join(ALICE_DIR, p))


def load_config() -> dict:
    example = os.path.join(SERVER_DIR, "conf", "alice.example.json")
    if not os.path.exists(CONFIG_FILE) and os.path.exists(example):
        shutil.copy(example, CONFIG_FILE)
        print(f"        config: created {CONFIG_FILE} from example")
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                data = json.load(f)
            merged = {**_DEFAULT_CONFIG, **data}
            for key in ("image", "tts", "llama_server", "memory", "llm_params", "demo"):
                merged[key] = {**_DEFAULT_CONFIG[key], **data.get(key, {})}
            for key in ("banned_phrases",):
                merged[key] = list(_DEFAULT_CONFIG.get(key, [])) + list(data.get(key, []))
            merged["model_path"] = resolve_path(merged.get("model_path", ""))
            merged["llama_server_path"] = resolve_path(merged.get("llama_server_path", ""))
            merged["model_dir"] = resolve_path(merged.get("model_dir", ""))
            if "system_prompt" not in data and "modelfile" in data:
                m = re.search(r'SYSTEM\s+"""(.*?)"""', data["modelfile"], re.DOTALL)
                if m:
                    merged["system_prompt"] = m.group(1).strip()
            print(f"        config: loaded {CONFIG_FILE}")
            return merged
        except Exception as e:
            print(f"        WARNING: could not load {CONFIG_FILE}: {e} -- using defaults")
    return {**_DEFAULT_CONFIG}


def save_config(cfg: dict):
    try:
        to_save = {**cfg}
        default_banned = set(_DEFAULT_CONFIG.get("banned_phrases", []))
        to_save["banned_phrases"] = [p for p in cfg.get("banned_phrases", []) if p not in default_banned]
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(to_save, f, indent=4, ensure_ascii=False)
    except Exception as e:
        print(f"        WARNING: Could not save config: {e}")


def load_personas(cfg: dict) -> dict:
    if not os.path.exists(PERSONAS_FILE):
        # First-run seed: philosophers pack. Alice now lives only in mine.json.
        src = os.path.join(PACKS_DIR, "philosophers.json")
        if not os.path.exists(src):
            src = os.path.join(SERVER_DIR, "conf", "personas.example.json")
        if os.path.exists(src):
            shutil.copy(src, PERSONAS_FILE)
            print(f"        config: created {PERSONAS_FILE} from {os.path.basename(src)}")
    if os.path.exists(PERSONAS_FILE):
        try:
            with open(PERSONAS_FILE, encoding="utf-8") as f:
                data = json.load(f)
            data = {k: v for k, v in data.items() if not v.get("disabled")}
            return data
        except Exception as e:
            print(f"WARNING: could not load personas.json: {e}")
    return {}


def get_persona_packs() -> list[str]:
    packs = []
    if os.path.exists(PACKS_DIR):
        for f in os.listdir(PACKS_DIR):
            if f.endswith(".json"):
                packs.append(f[:-5])
    if os.path.exists(MINE_DIR):
        for f in os.listdir(MINE_DIR):
            if f.endswith(".json"):
                packs.append(f"mine/{f[:-5]}")
    return sorted(packs)


def reload_personas():
    global PERSONAS
    PERSONAS = load_personas(CFG)


def banned_phrases_note(cfg: dict = None) -> str:
    phrases = (cfg or CFG).get("banned_phrases", [])
    if not phrases:
        return ""
    joined = ", ".join(f'"{p}"' for p in phrases)
    return f"\n\nNEVER use these words or phrases under any circumstances: {joined}."


CFG      = load_config()
NAME     = CFG.get("name", "Alice")
PERSONAS = load_personas(CFG)
PORT     = int(CFG.get("port", 8000))
ALICE_URL = f"http://localhost:{PORT}"
